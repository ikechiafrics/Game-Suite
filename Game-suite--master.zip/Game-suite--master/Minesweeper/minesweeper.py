from minesweeper_functions import play, music

if __name__ == "__main__":
    music()
    play()